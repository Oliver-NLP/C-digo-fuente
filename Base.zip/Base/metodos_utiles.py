import os
import numpy as np

#Funciones para recuperar los archivos .txt de una carpeta y ordenarlos por su id unico en el nombre de archivo
#Separa la ruta de una carpeta
def list_path_text(path, ends='.txt'):
    #Se obtienen los nombres (rutas) de todos los archivos que finalicen con .txt
    list_paths = [x for x in os.listdir(path) if x.endswith(ends)]
    #Obtenemos los indices ordenamos por el identificador único que llevan en su nombre de archivo
    idx_sort = np.argsort([int(x.split('.')[0]) for x in list_paths])
    #Ordenamos los nombres de los archivos txt
    paths = [list_paths[x] for x in idx_sort]
    #unimos estos nombres a la ruta de la carpeta para obtener la ruta de las novelas ordenadas
    return [path_novel(path, p) for p in paths]

#Une dos cadenas para formar la ruta con esto, la ruta raíz y el nombre del archivo
def path_novel(root_path, novel_file):
    return os.path.join(root_path, novel_file)

#Devuelve verdadero si el token NO es un signo de puntuación o espacion en blanco
def condition_clean(token):
    return conditions_req(token, [('is_punct', False), ('is_space', False)])#not atribute_return(t, 'is_punct') and not atribute_return(t, 'is_space') 

#Devuelve verdadero si el token NO es un signo de puntuación o espacion en blanco o stopword
def condition_clean_stop(token):
    return conditions_req(token, [('is_punct', False), ('is_space', False), ('is_stop', False)])#not atribute_return(t, 'is_punct') and not atribute_return(t, 'is_space') and not atribute_return(t, 'is_stop')

#Se pasa el token y las condiciones que debe cumplit en formato (atributo, valor esperado de condición)
def conditions_req(token, conditions):
    return all(getattr(token, att) == expected for att, expected in conditions)
