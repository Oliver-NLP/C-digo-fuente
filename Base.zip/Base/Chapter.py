from Sent_token import Sent_token
from metodos_utiles import condition_clean, condition_clean_stop

#Contiene tantas listas como oraciones tenga el capítulo, estas listas son objetos tipo Sent_token
class Chapter():
    #Dependiendo de condition, cambia el valor de len en la oracion, con condition_clean no toma en cuenta los signos de puntuación ni espacios en blanco
# con condition_clean_stop no toma en cuenta los signos de puntuación ni espacios en blanco ni los stopwords
    #Recibe el un objeto doc que tiene las oraciones Sent_token del capítulo, este doc es un doc de spaCy
    def __init__(self, doc, num_chap, condition):
        #Obtenemos el numero de capitulo
        self.num_chap = num_chap
        #Obtenemos las oraciones del capítulo
        self.sents = [Sent_token(sent, condition) for sent in doc.sents]
        for e, sent in enumerate(self.sents):
            #Acualtizamos el identificador de la oración
            sent.i = e
            for token in sent:
                #Si el Token_primitive no es un espacio en blanco o signo de puntuacion
                if not token.is_space and not token.is_punct:
                    #Obtenemos la distancia de depencia del token a su gobernante y actualizamos su valor
                    token.dd = self.dd_token(doc, token)

    #Se habilita para que trabaje como un iterable el cual contiene Sent_token los cuales son las oraciones del texto
    def __iter__(self):
        return iter(self.sents)

    #Se habilita para que se pueda solicitar una oración con su índice
    def __getitem__(self, start, end=None):
        if end == None:
            return self.sents[start]
        #O una secuencia de oraciones
        else:
            start_ = self.sents[start].i
            end_ = self.sents[end].i
            return [x for x in self.sents if x.i>= start_ and x.i<=end_]

    #Se habilita len para obtener el total de oraciones
    def __len__(self):
        return len(self.sents)
   
    def __repr__(self):
        return f'Capítulo {self.num_chap+1},  oraciones: {len(self.sents)}'

   #funcion para obtener la distancia de dependecia de un token a su gobernante
    def dd_token(self, doc, token):
        #tomamos la rebanada del token a su palabra gobernante con su identificador spaCy
        if token.i == token.head.i:
          #Solo el token raíz de la oración es su propio gobernante y por definición su distancia es 0
          slice = doc[token.i : token.i]
        elif token.i < token.head.i:
          #si el token esta a la izquierda de su gobernante
          slice = doc[token.i : token.head.i]
        else:
          #Si el token esta a la derecha de su gobernante
          slice = doc[token.head.i : token.i]
        #Contabilizamos el número de token si tener en cuenta los espacios en blanco y signos de puntuación
        return len([x for x in slice if not x.is_punct and not x.is_space])