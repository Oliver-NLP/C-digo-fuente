from Process import Process
from Book import Book
from metodos_utiles import list_path_text
import numpy as np                      #Manejo eficaz de arreglos
from collections import Counter         #Conteo de ocurrencias
import matplotlib.pyplot as plt         #Gráficos
import matplotlib.cm as cm      # mapas de color
import pandas as pd                     #Uso de dataframes

class Stylometrics(Process):
    def __init__(self):
        super().__init__()
        self.columns = ['Novela', 'Publicado', 'Edad', 'total vocabulario', 'total lemmas', 'total de palabras', 'tamaño promedio de palabras', 'porcentaje de oraciones de narrativa', 'total de oraciones', 'tamaño promedio de oración', 'MDD', 'proporcion stopwords', 'stopword promedio por oración']

    def set_attribute(self, text_plane, att):
        #recorre cada token el la lista texplane, convierte al token en su atributo correspondiente y hace un conjunto de esto 
        #para tener valores unicos, los ordena y los devuelve
        return sorted(set([getattr(t, att) for t in text_plane]))
    
    def stylometrics_measurements(self, root_book, author, columns, birth, condition):
        #Se prepara el dataframe con los datos que se van a calcular
        novel_dict = dict.fromkeys(columns, None)
        #Se obtiene el objeto Book de la novela
        novel = Book(root_book, condition)
        #Se añade como atributo el nombre del autor
        setattr(novel, 'author', author)
        #Se actualiza el nombre de la novela
        novel_dict['Novela'] = novel.name_novel
        #Se actualiza la fecha de publicación
        novel_dict['Publicado'] = int(root_book.split('.')[-2])
        #Se actualiza la edad del autor a la fecha de publicación
        novel_dict['Edad'] = novel_dict['Publicado']- birth
        #Narrativa de la novela
        narrativa = self.separate_novel(novel_spaCy=novel, is_narrative=True)
        #total de oraciones en la narrativa
        num_sent_nar = sum([len(x) for x in narrativa])
        novel_dict['total de oraciones'] = num_sent_nar
        #total de palabras en la narratica
        num_pal_nar = sum([len(sent) for chap in narrativa for sent in chap])
        novel_dict['total de palabras'] =  num_pal_nar
        dialogo = self.separate_novel(novel_spaCy=novel, is_narrative=False)
        num_sent_dia = sum([len(d) for d in dialogo])
        novel_dict['porcentaje de oraciones de narrativa'] = round(num_sent_nar/(num_sent_nar+num_sent_dia), 4)
        novel_dict['tamaño promedio de oración'] = round(np.array([len(s) for c in narrativa for s in c]).mean(), 4) 
        text_plane = [t for chap in narrativa for sent in chap for t in sent if condition(t)]
        novel_dict['total vocabulario'] = round(len(self.set_attribute(text_plane, 'text')), 4)
        novel_dict['total lemmas'] = round(len(self.set_attribute(text_plane, 'lemma_')), 4)
        novel_dict['tamaño promedio de palabras'] = round(np.array([len(t) for c in narrativa for s in c for t in s]).mean(), 4)
        #Distancia de dependencia promedio
        dd = [getattr(t, 'dd') for t in text_plane if condition(t)]
        novel_dict['MDD'] = round(sum(dd)/(len(dd)-num_sent_nar), 4)
        novel_dict['proporcion stopwords'] = round(len([t for t in text_plane if t.is_stop])/len(text_plane), 4)
        novel_dict['stopword promedio por oración'] = round(np.array([len([t for t in sent if t.is_stop])/len(sent) for chap in narrativa for sent in chap if len(sent)!=0]).mean(), 4) 
        return novel_dict
        
    def lexical_syntactic(self, root_path, author, birth, condition):
        paths = list_path_text(root_path)
        novel_lex = []
        for root_novel in paths:
            novel_lex.append(self.stylometrics_measurements(root_novel, author, self.columns, birth, condition))
        return pd.DataFrame(novel_lex)  

      #, 'PRON', 'DET']#u#ad_pos + pron_pos#['NOUN', 'VERB', 'DET', 'PRON']# subj_tag + verbs_tag
        #['PRONP']
    def behaivor_novel(self, root_book, author, condition, samples=10, att= 'pos_', categories = ['NOUN', 'VERB'], removes_cat = []):    
        novel = Book(root_book, condition)
        setattr(novel, 'author', author)
        narrativa = self.separate_novel(novel_spaCy=novel, is_narrative=True)
        #total de oraciones en la narrativa
        num_sent_nar = sum([len(x) for x in narrativa])
        
        sent_narr = [sent for chap in narrativa for sent in chap]
        
        #Total de oraciones en cada muestra
        entero = num_sent_nar//samples
        ult = entero + (num_sent_nar % samples)
        print(f'Cada muestra tienen un total de {entero} oraciones, excepto la última que tiene {ult}')

        #Encontramos las distribuciones por cada muestra en diccionarios que tienen como llave la lista de categorias (text, lemma_, pos_, tag_) 
        # y como valor el contedo de estas en la muestra
        accounts = []
        for c in range(samples):
            idx_min = c*entero
            idx_max = (c+1)*entero
            if c == samples-1:
                idx_max = num_sent_nar
            #inicializamos la lista que contendra los tokens de la muestra actual
            tokens_actuales = []
            for i in range(idx_min, idx_max):
                #tomamos el atributo de cada token ignorando los espacios en blanco
                sent_actual = [getattr(x, att) for x in sent_narr[i] if condition(x)]
                #Agregamos todos los tokens de todas las oraiciones a nuestra lista de tokens actual
                tokens_actuales+= sent_actual
            #Hacemos el conteo de los tokens de cada muestra
            accounts.append(dict(sorted(Counter(tokens_actuales).items())))
        #Encontramos todas las llaves utilizadas
        u = sorted(set().union(*accounts))
        #Corregimos los valores de las distribuciones para que todas tengan la misma dimension y la misma columna para poder comparar
        distr = []

        for dist in accounts:
            #Los valores que ya tenemos los actualizamos y las llaves que no tiene esta novela pero que estan en otra obra se pone en 0
            dic = {k: dist.get(k, 0) for k in u}
            distr.append(self.normaliza_accounts(dic))

      
        for m in  [c for c in categories if c not in removes_cat]:
            val = m
            x = [i for i in range(len(distr))]
            y = []
            for d in distr:
                y.append(d[val])
            plt.plot(x, y, label =f'{val}')
            
        plt.title(f'Categorías de {novel.author} en la\nnovela {novel.name_novel}') 
        plt.xlabel(f'Porción de oraciones tomadas')
        plt.ylabel(f'Proporción de las categorías en la novela')
        plt.xticks([i for i in range(len(distr))], [(i*entero, (i+1)*entero) if i!= len(distr)-1 else (i*entero, num_sent_nar) for i in range(len(distr))], rotation=90)
        self.activate_grid(plt)
        plt.legend()
        plt.show()    
    
    def leyHeaps(self, novel_spaCy, att, condition):    
        narrativa = self.separate_novel(novel_spaCy=novel_spaCy, is_narrative=True)
        tokens = [token for chap in narrativa for sent in chap for token in sent if condition(token)] # and not token.is_stop]
        vocabulario = set()
        vector = []
        for e, t in enumerate(tokens):
            vocabulario.add(str(getattr(t, att)))
            vector.append((e+1, len(vocabulario)))
        x = np.array([x for x, y in vector])
        y = np.array([y for x, y in vector])
    #    plt.plot(x, y, label = 'Original')
        k_fit, B_fit, y_aj = self.function_fit(x, y)
    #    plt.plot(x, y_aj, label=f'Ley Heaps \nk={round(k_fit,3)}\nB={round(B_fit,3)}\nr**2={round(self.pearson_r(y_aj, y)**2,3)}\neam={round(self.mean_absolut_error(y_aj, y),3)}\necm={round(self.mean_square_error(y_aj, y),3)}\nerm={round(self.mean_relative_error(y_aj, y),3)}', linestyle='--')
    #    plt.xlabel('Total de tokens')
    #    plt.ylabel('Tamaño de vocabulario')
    #    self.activate_grid(plt)
    #    plt.title(f'Vocabulario vs total tokens de la novela {novel_spaCy.name_novel}')
    #    plt.legend()
    #    plt.show()
        return x, y, k_fit, B_fit

    def vocabulary_vs_token(self, root_path, birth, author, att, condition):
        K_t = []
        B_t = []
        function_V = []
        novelas = [n.split('.')[-3] for n in list_path_text(root_path)]
        publisn_novels = [int(n.split('.')[2]) for n in list_path_text(root_path)]
        vect_=[]

        for path in list_path_text(root_path):
            novel = Book(path, condition)
            #novelas.append(novel.name_novel)
            x, y, k_fit, B_fit = self.leyHeaps(novel, att, condition)
            vect_.append((x, y))
            K_t.append(k_fit)
            B_t.append(B_fit)
            function_V.append(k_fit*(x**(B_fit)))
        
        cmap = cm.turbo  # puedes cambiar el colormap
        colors = cmap(np.linspace(0, 1, len(function_V)))
        #fig, ax = plt.subplots(2, 1, figsize=(15, 30), sharex=True)
        curvas = []
        for e, ((x,y), z) in enumerate(zip(vect_, function_V)):
            curvas.append((x, y, z))
            fig, ax = plt.subplots(1, 1, figsize=(8, 9), sharex=True)
            for i, (cx, cy, cz) in enumerate(curvas):
                if e != i:
                #    ax[0].plot(cx, cy, label = f'{novelas[i]}--{publisn_novels[i]}', color=colors[i])
                    plt.plot(cx, cz, label = f'{novelas[i]}--{publisn_novels[i]}', color=colors[i])
                else:
                #    ax[0].plot(cx, cy, '--', linewidth=3.5, label = f'{novelas[i]}--{publisn_novels[i]}', color=colors[i])
                    plt.plot(cx, cz, '--', linewidth=3.5, label = f'{novelas[i]}--{publisn_novels[i]}', color=colors[i])
        #    fig.supxlabel('Total de tokens')
            plt.xlabel('Total de tokens')
        #    fig.supylabel('Tamaño de vocabulario')
            plt.ylabel('Tamaño de vocabulario')
        #    ax[0].set_title(f'Vocabulario vs Tokens (Original) para la autora {author}')    
            plt.title(f'Modelo matemático de aproximación \nf(x) = k * (x**β) para la autora {author}')
        #    Stil.activate_grid(ax[0])
        #    ax[0].legend()
            self.activate_grid(plt)
            plt.legend()
        plt.show()
        
        fig, ax = plt.subplots(2, 1, figsize=(7,7), sharex=True)
        ax[0].plot(np.array(publisn_novels)-birth, K_t, label=f'Comportamiento de k en las distintas novelas')
        self.activate_grid(ax[0])
        ax[0].set_title(f'Modelo matemático de aproximación f(x) = k * (x**β)')
        ax[0].legend()
        #plt.show()
        ax[1].plot(np.array(publisn_novels)-birth, B_t, label = f'Comportamiento de β en las distintas novelas')
        self.activate_grid(ax[1])
        ax[1].set_xticks(np.array(publisn_novels)-birth,np.array(novelas), rotation=90)
        ax[1].legend()
        return pd.DataFrame({'novelas': novelas,'k voca': K_t, 'betta voca': B_t, 'func V': function_V})
