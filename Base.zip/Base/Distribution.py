from Process import Process
import matplotlib.pyplot as plt         #Graficos
import numpy as np                      #Manejo eficaz de arreglos
import spacy                            #Procesamiento del lenguaje natural

class Distribution(Process):
    def __init__(self):
        super().__init__()
        self.datemin = 1954
        self.datemax = 2012

    def distributionOnTime(self, books_spaCy, att, is_narrative= True):
        #Obtenemos el conteo de ocurrecias del atributo (att) en la novela
        OriDistribution = [self.accounts_book(novel_spaCy = getattr(books_spaCy, novel), att=att, is_narrative= is_narrative)   for novel in books_spaCy.mynovels]
        #Encontramos todas las llaves utilizadas
        u = sorted(set().union(*OriDistribution))
        #Corregimos los valores de las distribuciones para que todas tengan la misma dimension y la misma columna para poder comparar
        ObjDistr = []
        for dist in OriDistribution:
            #Los valores que ya tenemos los actualizamos y las llaves que no tiene esta novela pero que estan en otra obra se pone en 0
            dic = {k: dist.get(k, 0) for k in u}
            dic = dict(sorted(dic.items()))
            ObjDistr.append(self.normaliza_accounts(dic)) 
        return ObjDistr
    
    #Capturar solo una categoria en el tiempo
    def labels_on_the_time(self, att, books_spaCy, label_find=False):
        #Diccionario para la etiqueta en el tiempo
        label_ = dict()    
        dstb = self.distributionOnTime(books_spaCy= books_spaCy, att= att, is_narrative=True)
        #Recorremos cada una de las novelas
        for e, novel in enumerate(books_spaCy.mynovels):
            #recuperamos de esta la categoria        
            try:
                label_[novel] = dstb[e][label_find]
            except KeyError:
                label_[novel] = 0
        #Regresamos el diccionario de solo una categoria en el tiempo (label_)
        return label_

    #Desplegar la probabilidad de ocurrencia de una lista de categorias gramaticales a lo largo de las diferentes novels 
    def beteween_grammar(self, find_cat, att, books_spaCy, is_Murdoch=True, ax=plt, fontsize=20, linewidth=3.5):
        publish_novels = [int(x) for x in books_spaCy.publish_n]
        for f in find_cat:
            #Encontramos la probabilidad en las diferentes novelas y lo dibujamos en la misma grafica
            one_label = self.labels_on_the_time(att =att, label_find = f, books_spaCy=books_spaCy)
            ax.plot(publish_novels, [y for y in one_label.values()], label=f, marker='x', linewidth=linewidth)
        #Encontramos la edad del autor para la fecha de publicación de cada novela
        ages = np.array(publish_novels) - books_spaCy.birth 
        if ax == plt:
            #Asignamos las etiquetas del eje X el cual son las novelas y colocamos tituloo al grafico y a los ejes y una legenda con las categoras desplegadas
            _ = ax.xticks(publish_novels, list(zip([y for y in one_label.keys()], list(zip(books_spaCy.publish_n,ages)))), rotation=90)
            ax.title(f'Categorias de {"Murdoch" if is_Murdoch else "James"} a lo largo de su trayectoria', fontsize=fontsize+5)
            ax.xlabel(f'Novelas', fontsize=fontsize)
            ax.ylabel(f'Proporción de las categorias en la novela', fontsize=fontsize)
            ax.xlim(self.datemin-1, self.datemax+1)
        else:
            #Asignamos las etiquetas del eje X el cual son las novelas y colocamos tituloo al grafico y a los ejes y una legenda con las categoras desplegadas
            _ = ax.set_xticks(publish_novels, [x for x in books_spaCy.mynovels], rotation=90)
            ax.set_title(f'Categorias de {"Murdoch" if is_Murdoch else "James"} a lo largo de su trayectoria', fontsize=fontsize+5)
            ax.set_xlabel(f'Novelas', fontsize=fontsize)
            ax.set_ylabel(f'Proporción de las categorias en la novela', fontsize=fontsize)
            ax.set_xlim(self.datemin-1, self.datemax+1)
        self.activate_grid(ax)
        ax.tick_params(axis='both', labelsize=fontsize-5)
        ax.legend(loc='upper center', ncol= len(find_cat)/2, fontsize=fontsize-5)
    
    def show_labels_one_by_one(self, list_labels, att, books_spaCy, label_per_row=5, is_Murdoch=True, figsize=(50,50)):
        #inicializamos el indicie de las etiquetas en 0
        idx_label=0
        #Encontramos el total de categorias gramaticales que debemos mostrar
        n_total = len(list_labels)
        #Entontramos el total de renglones que tendremos de imagenes de las etiquetas
        n_row = n_total // label_per_row + (1 if n_total % label_per_row != 0 else 0)
        fig, axs = plt.subplots(ncols=label_per_row, nrows=n_row, figsize=figsize)
        for row in range(n_row):
            for col in range(label_per_row):
                #Si el indice de las etiquetas es menor al total de quebo mostrar
                if idx_label <n_total:
                    #Busco la etiqueta con el i-ésimo índice
                    find = list_labels[idx_label]
                    #Entontramos su comportamiento a lo largo de las diferentes novelas y los dibujamos en su correspondiente lugar asignado
                    test = self.labels_on_the_time(att = att, label_find = find, books_spaCy=books_spaCy)
                    x = [int(i) for i in books_spaCy.publish_n] #[k for k in range(len(test.keys()))]
                    y = [v for v in test.values()]
                    axs[row, col].plot(x, y, label=f'{find}', color = 'g')            
                    axs[row, col].set_title(f'{find} :  {spacy.explain(find)}', fontsize=12)
                    axs[row, col].set_xlim(self.datemin-1, self.datemax+1)
                    self.activate_grid(axs[row, col])
                    #Aumentamos en 1 el índice de la etiqueta para poder buscar la siguiente en la siguiente iteración                
                    idx_label += 1
                else:
                    axs[row, col].set_xlim(self.datemin-1, self.datemax+1)
                #Solo a las figuras de la último renglón se les pone etiquetas en el eje x ya que es lo mismo para todas las demas
                if row == n_row -1:
                        axs[row, col].set_xticks(x, [k+1 for k in range(len(books_spaCy.mynovels))], rotation=90)#list(zip([k for k in test.keys()], books_spaCy.publish_n)), rotation=90)            
        #Agregamos el titulo a los graficos dependiendo si el autor fue I. Murdoch o no
        fig.suptitle(f'Distribución en el tiempo de las etiquetas tipo {att}\npara el autor {"Iris Murdoch" if is_Murdoch else "P.D. James"}', fontsize=20)