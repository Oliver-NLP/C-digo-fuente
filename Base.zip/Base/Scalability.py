from Similarity import Similarity
from Book import Book
import numpy as np                      #Manejo eficaz de arreglos
import random                           # aletorios
from collections import Counter         #Conteo de ocurrencias
import os                               #Manejo de carpetas y archivos
import pandas as pd                     #Uso de dataframes
import matplotlib.pyplot as plt         #Graficos
import matplotlib.cm as cm      # mapas de color
from metodos_utiles import list_path_text

class Scalability(Similarity):
    def __init__(self):
        super().__init__()
        
    #Devuelve un vector con el total de oraciones que se deben tomar por capítulo de la novela para tener un total de application_sent oraciones
    def distribution_sents(self, solicitud_sent, narrative):
        #Obtengo el total de capitulos
        tot_chapt = [len(x) for x in narrative]
        #Bandera para saber si aun tiene oraciones disponibles el capitulo
        flag = np.ones(len(tot_chapt))
        #total de oraciones que se deben tomar por capitulo
        disp = np.zeros(len(flag))
        #si piden menos oraciones de las que hay dispobibles en toda la novela
        if solicitud_sent<sum(tot_chapt):
            #encuentro la parte entera que podria tocar de oraciones en cada capitulo para estar balanceado
            ent = solicitud_sent//len(flag)
            #Recorro los capitulos 
            for a in range(len(flag)):
                #si al sumar la parte entera se para de el maximo de oraciones 
                if disp[a]+ent > tot_chapt[a]:
                    #pongo la bandera de ese capitulo en 0 para indicar que no hay mas oraciones
                    flag[a] = 0
                    #y coloco el maximo de oraciones de este capitulo
                    disp[a] = tot_chapt[a]
                else:
                    #Si aun hay oraciones disponibles entonces las agrego 
                    disp[a]+= ent
            #Veo los capitulo que aun tinene oraciones dispobles
            able = np.nonzero(flag)[0]
            #Ecuentro el numero de oraciones que me hacen falta para tener la que solicitaron
            falta = solicitud_sent-sum(disp)
            #Mientras no tenga todas las oraciones
            while falta >0:
                #recorro los capitulos que aun tenian oraciones
                for a in able:
                    #si su bandera sigue dispobible y aun me faltan oraciones
                    if flag[a] == 1 and falta>0:
                        #Veo si al sumarle una oracion se excede
                        if disp[a]+1 > tot_chapt[a]:
                            #entonces pongo su bandera en 0 para indicar que ya no hay oraciones diponibles
                            flag[a] = 0
                        else:
                            #Si aun le quedan oraciones agrego de una en una 
                            disp[a]+= 1
                            #y resto uno a las oraciones faltantes
                            falta-=1
        else:#en caso de que pidan mas oraciones de las disponibles, entrego todas las que hay
            disp = tot_chapt      
        return disp
    
    #Toma una muestra de la novela
    def sample_novel(self, narrative, total_sample):
        samples = self.distribution_sents(total_sample, narrative)
        samples = [random.sample(narrative[e], int(s)) for e, s in enumerate(samples)]
        return [s for sample in samples for s in sample]
    
    #Hace el conte de ocurrencias de en la muestra
    def accounts_sample(self, att, narrativa, total_sents):
        muestra = self.sample_novel(narrativa, total_sents)
        return dict(sorted(Counter([getattr(token, att) for sent in muestra for token in sent if not token.is_space]).items()))

    def scalability_(self, narrative, att):
        resultado = []
        distancia_coseno = []
        distancia_jessen = []
        x=[]
        #obtiene el numero de oraciones en la narrativa de la novela
        num_sent = sum([len(n) for n in narrative])
        #Obtine el distribución de ocurrencias del attributo att en la novela  
        original =  self.normaliza_accounts(dict(sorted(Counter([getattr(token, att) for chap in narrative for sent in chap for token in sent if not token.is_space]).items())))
        keys = list(original.keys())

        while num_sent > 0:
            #tomo una muestra con num_sent oraciones de la novela y encuentro su conteo de ocurrencias respetando las llaves de toda la novela inicializadas en 0
            dic_sample = dict.fromkeys(keys, 0)
            sample = self.accounts_sample(att, narrative, num_sent)
            for s in sample.keys():
                dic_sample[s] = sample[s]
            dic_sample = self.normaliza_accounts(dic_sample)
            resultado.append(dic_sample)
            #Encontramos las distancias de similitud de la muestra a las de toda la novela
            distancia_coseno.append(self.distance_cosine(np.array(list(original.values())), np.array(list(dic_sample.values()))))
            distancia_jessen.append(self.distance_JensenShannon(np.array(list(original.values())), np.array(list(dic_sample.values()))))            
            x.append(num_sent)
            #Diminuyo en 100 el número de oraciones de la muetra
            num_sent -=100
        x = np.array(x)
        x = x/x.max()
        #Applicamos la tranformación para normalizar
        distancia_coseno = np.array(distancia_coseno)
        distancia_coseno = distancia_coseno/distancia_coseno.max()
        distancia_jessen = np.array(distancia_jessen)
        distancia_jessen = distancia_jessen/distancia_jessen.max()
        #   El vector x, distancia coseno y jensen se devuelven al reves, ya que se fue decrementando las oraciones    
        return resultado, x[::-1], distancia_coseno[::-1], distancia_jessen[::-1]
    
    #Hace la autoescalabilidad de cada novela en root_path
    def test_scalability(self, root_path, att, total_repeat, condition):
        filas = []
        for root_book in list_path_text(root_path):
            k_fit_c, B_fit_c, k_fit, B_fit, x_vect = self.mean_scalability(root_book, att, total_repeat, condition)
            filas.append({'novela': root_book.split('.')[1].replace(' ', '_').replace(',', '').replace("'", '_'), 'k cos': k_fit_c, 'betta cos': B_fit_c, 'k jens': k_fit, 'betta jens': B_fit, 'x': x_vect})
        return pd.DataFrame(filas)

    #Hace el algoritmo scalability_ application veces 
    def mean_scalability(self, root_book, att, application, condition):
        novel = Book(root_book, condition)
        narrativa = self.separate_novel(novel_spaCy=novel, is_narrative=True)
        pila = True
        conta = 0
        filas_x = []
        filas_coseno = []
        filas_jenssen = []
        while pila:
            _, vec_x, d_cos, d_jes = self.scalability_(narrativa, att)
            filas_x.append(vec_x)
            filas_coseno.append(d_cos)
            filas_jenssen.append(d_jes)
            conta+=1
            if conta >= application:
                pila = False
        matrix_x = np.array(filas_x)
        matrix_cos = np.array(filas_coseno)
        matrix_jes = np.array(filas_jenssen)

        fig, ax = plt.subplots(1, 2, figsize=(12,5))

        A_fit_c, C_fit_c, y_aj_c = self.function_fit(matrix_x.mean(axis=0), matrix_cos.mean(axis=0))
        
        ax[0].plot(matrix_x.mean(axis=0), matrix_cos.mean(axis=0), label= f'Distancia coseno (redimensionado) promedio')
        ax[0].plot(matrix_x.mean(axis=0), A_fit_c*((matrix_x.mean(axis=0))**C_fit_c), '--', label = r'No lineal, $A_{0}*(x**c)$'f', \n'r'$A_{0} =$'f', {round(A_fit_c, 4)}, C = {round((C_fit_c), 4)} R² = {round(self.pearson_r( matrix_cos.mean(axis=0), y_aj_c)**2, 4)}, \n, ECM = {round(self.mean_square_error( matrix_cos.mean(axis=0), y_aj_c), 4)}, EAM = {round(self.mean_absolut_error( matrix_cos.mean(axis=0), y_aj_c), 4)}')#\nERM = {round(self.mean_relative_error( matrix_cos.mean(axis=0), y_aj),4)}')
        self.activate_grid(ax[0])
        ax[0].set_title(f'Distancia coseno de la novela {novel.name_novel}')
        ax[0].set_xlabel(f'Proporción de oraciones tomadas de la novela')
        ax[0].set_ylabel(f'Distancias coseno redimensionada')
        ax[0].legend()
    #    plt.show()

        ax[1].plot(matrix_x.mean(axis=0), matrix_jes.mean(axis=0), label= f'Distancia jensen (redimensionado) promedio')
        A_fit, C_fit, y_aj = self.function_fit(matrix_x.mean(axis=0), matrix_jes.mean(axis=0))
        ax[1].plot(matrix_x.mean(axis=0), A_fit*((matrix_x.mean(axis=0))**C_fit), '--', label = r'No lineal, $A_{0}*(x**c)$'f', \n'r'$A_{0} =$'f', {round(A_fit, 4)}, C = {round((C_fit), 4)} R² = {round(self.pearson_r(matrix_jes.mean(axis=0), y_aj)**2, 4)}, \n, ECM = {round(self.mean_square_error(matrix_jes.mean(axis=0), y_aj), 4)}, EAM = {round(self.mean_absolut_error(matrix_jes.mean(axis=0), y_aj), 4)}')#\nERM = {round(self.mean_relative_error(matrix_jes.mean(axis=0), y_aj),4)}')
        ax[1].set_xlabel(f'Proporción de oraciones tomadas de la novela')
        ax[1].set_ylabel(f'Distancias Jensen-Shannon redimensionada')
        self.activate_grid(ax[1])
        ax[1].legend()
        plt.show()
        return A_fit_c, C_fit_c, A_fit, C_fit, matrix_x.mean(axis=0)

    #Grafica los valores de betta y k de la ley de potencias obtenida en la autosimilitud
    def betta_k_autosimilarity(self, df, label_k, label_betta, publish_novels, labels, name_author, figsize = (10, 6)):
        fig, ax = plt.subplots(2, 1, figsize=figsize, sharex=True)
        ax[0].plot(publish_novels, df[label_k], label=label_k)
        self.activate_grid(ax[0])
        ax[0].legend()
        ax[1].plot(publish_novels, df[label_betta], label=label_betta)
        ax[1].legend()
        self.activate_grid(ax[1])
        fig.suptitle(f'Parametros k y b, en la funcion f(x) = '+ r'$k\,x^{\beta}$'+f'\nen la autosimilitud de las novelas de {name_author}', fontsize=14)
        _ = ax[1].set_xticks(publish_novels, labels, rotation=90)
    
    #enterga un mapa de calor con las medidas de similitud entre las novelas
    def measure_similarity_novels(self, df, label_k, label_betta, name_author, distance_type, figsize):
        cmap = plt.cm.turbo
        colors = cmap(np.linspace(0, 1, len(df)))
        curvas = []
        for i in range(len(df)):
            curvas.append((df['x'][i], df[label_k][i] * (df['x'][i]**df[label_betta][i])))
            plt.figure(figsize=(figsize))
            for e,c in enumerate(curvas):
                if e!=i:
                    plt.plot(c[0], c[1], label= f"{df['novela'][e]}", color= colors[e])
                else:
                    plt.plot(c[0], c[1], '--', label= f"{df['novela'][e]}", color= colors[e],  linewidth=3.5)
            self.activate_grid(plt)
            plt.xlabel(f'Proporción de oraciones tomadas de la novela')
            plt.ylabel(f'Distancia {distance_type} redimensionada')
            plt.title(f'Autosimilitud de la distancia {distance_type} para {name_author}')
            texto = (
                r'$d(x)=k\,x^{\beta}$' '\n'
                r'$k \in [%.3f, %.3f]$' '\n'
                r'$\beta \in [%.3f, %.3f]$'
            ) % (
                df[label_k].min(),
                df[label_k].max(),
                df[label_betta].min(),
                df[label_betta].max()
            )
            plt.text(
            0.05, 0.95, texto,
            transform=plt.gca().transAxes,
            fontsize=11,
            verticalalignment='top',
            bbox=dict(boxstyle="round", facecolor="white", alpha=0.85)
            )
            plt.legend()
            plt.show()