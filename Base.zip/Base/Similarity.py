from Distribution import Distribution
import numpy as np                      #Manejo eficaz de arreglos
import pandas as pd                     #Uso de dataframes
from scipy.special import rel_entr    #Calculo de la divergencia de kulback
import itertools as it                 #Manejo eficaz de combinaciones 
import matplotlib.pyplot as plt         #Graficos
import seaborn as sns                 #Manejo de graficos

class Similarity(Distribution):
    def __init__(self):
        super().__init__()
    
    #Divergencia de Kullback
    def kullback(self, P, Q):
        return np.sum(rel_entr(P, Q))

    #divergencia de Jensen-Shannon
    def divergence_JensenShannon(self, P, Q):
        M = (P + Q)/2
        return(self.kullback(P, M) + self.kullback(Q, M))/2

    #Distancia Jensen-Shannon
    def distance_JensenShannon(self, P, Q):
        return np.sqrt(self.divergence_JensenShannon(P, Q))
    
    #Norma de un vector
    def norma(self, vect):
        return np.sqrt(vect@vect)

    #similitud coseno
    def similarity_cosine(self, vect1, vect2):
        return (vect1*vect2).sum() / (self.norma(vect1)*self.norma(vect2))

    #distancia coseno
    def distance_cosine(self, vect1, vect2):
        return 1 - self.similarity_cosine(vect1.astype(float),vect2.astype(float))
    
    #Matriz de distancias
    def matrix_distance(self, Names, distributions, funct_distance):
        size = len(Names)

        Matriz = pd.DataFrame(
            np.zeros((size, size)),
            columns=Names,
            index=Names
        )
        #se obtenen los valores de la matiz diagonal superior e inferior
        for w1, w2 in list(it.combinations([x for x in range(len(Names))],2)):
            dist = funct_distance(distributions[w1], distributions[w2])
            Matriz.loc[Names[w1],Names[w2]] = dist
            #dado que la distancia de c a b es igual a la distancia de b a c
            Matriz.loc[Names[w2],Names[w1]] = dist
        #se obtienen los valores de la diagonal
        for i in range(len(Names)):
            dist = funct_distance(distributions[i], distributions[i])
            Matriz.loc[Names[i],Names[i]] = dist
        return Matriz
    
    #Muestra la matriz de similitud
    def show_matrix_similarity(self, matrix, name_matrix, labels, att, fontsize=20):
        plt.figure(figsize=(25, 25))
        sns.heatmap(matrix, annot=True, fmt=".5f", cmap="coolwarm", square=True, #vmin=0, vmax=1,
            xticklabels=labels,
            yticklabels=labels,
            annot_kws={
                        "weight": "bold",
                        "color": "black"   
                    }
            )
        plt.title(f"Matriz de distancias {name_matrix} usando el atributo {att} en las diferentes novelas", fontsize=fontsize+5)
        plt.tick_params(axis='both', labelsize=fontsize-5)
        plt.xticks(rotation=90)
        plt.yticks(rotation=0)
        plt.tight_layout()
        plt.show()
    
    #Autosimilitud de categorias gramaticales
    def auto_similarity(self, choise_att, books_spaCy):
        distribution_categories = []
        #encontramos las categorias gramaticales
        h_dist = self.distributionOnTime(books_spaCy, choise_att, is_narrative=True)
        #Convertimos la distribucion de cada novela en un arreglo numpy para poder trabajar mejor
        for e, novel in enumerate(books_spaCy.mynovels):
            distribution_categories.append(np.array([i for i in h_dist[e].values()]))
        #Obtenemos los nombres de las novelas y sus respectivass distribucion de categorias
        temp_att = list(zip(books_spaCy.mynovels, distribution_categories))
        #Obtenemos las matrices de similitud de jensen-shannon y coseno
        Matriz_Jensen_Shannon = self.matrix_distance(list(books_spaCy.mynovels), [y for x, y in temp_att], self.distance_JensenShannon)
        Matriz_Coseno = self.matrix_distance(list(books_spaCy.mynovels), [y for x, y in temp_att], self.distance_cosine)
        #Mostramos las matrices
        #age = np.array([int(x) for x in books_obj.publish_n]) - books_obj.birth
        self.show_matrix_similarity(Matriz_Jensen_Shannon, 'Jensen-Shannon', [x for x in books_spaCy.mynovels], choise_att)
        self.show_matrix_similarity(Matriz_Coseno, 'coseno', [x for x in books_spaCy.mynovels], choise_att)
        #se tempuelve la distribucion de categorias de cada novela
        return temp_att