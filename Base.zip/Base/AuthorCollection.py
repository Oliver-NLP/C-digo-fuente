from Book import Book
import os
import numpy as np
from metodos_utiles import list_path_text, condition_clean, condition_clean_stop


#Se pasa como argumento la ruta de la capeta donde estan los archivos .txt con las novelas de autor a analizar, el nombre del autor y su fecha de nacimiento
class AuthorCollection():
    #Dependiendo de condition, cambia el valor de len en la oracion, con condition_clean no toma en cuenta los signos de puntuación ni espacios en blanco
# con condition_clean_stop no toma en cuenta los signos de puntuación ni espacios en blanco ni los stopwords
    def __init__(self, autor_path_novels, author, birth, condition):
        #Se obtienen todas las rutas de los archivos con terminación .txt 
        path_novels = list_path_text(autor_path_novels)
        #Dado que las rutas vienen con un formato "Id_único.novela.fecha_pub", 
        temp = [p.split('.') for p in path_novels]
        #Se obtiene el nombre de las novelas
        self.mynovels = [p[-3].replace(",", '').replace("'", '_').replace(' ', '_') for p in temp]
        #Se obtienen la fecha de publicación 
        self.publish_n = [p[-2] for p in temp]
        #El nombre del autor
        self.author = author
        #Fecha de nacimiento
        self.birth = birth
        #Edad a la fecha de publicación
        self.ages = np.array([int(x) for x in self.publish_n]) - self.birth
        #Se recorren todas las novelas que hay
        for e, p in enumerate(path_novels):
            #Se genera un nuevo atributo con el nombre de la novela el cual contiene un objeto tipo book que contienen todo el texto ya tokenizado por spacy
            setattr(self, self.mynovels[e], Book(p, condition))
            print(f'Se completo el tokenizado y etiquetado de la novela {p.split(".")[-3]} del autor {author}')

    #Se habilita que funcione como spacy   
    def __iter__(self):
        return iter(self.mynovels)        

    #se habilita que se pueba obtener el total de elementos del iterable
    def __len__(self):
        return len(self.mynovels)
    
    #Se habilita su representación del objeto con el nombre del autor y el nombre de la novela
    def __repr__(self):
        return f'Autor: {self.author}, novelas: {self.mynovels}'