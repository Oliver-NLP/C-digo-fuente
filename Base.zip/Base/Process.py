from operator import itemgetter          #Recuperar atributos de objetos
from collections import Counter         #Conteo de ocurrencias
import numpy as np                      #Manejo eficaz de arreglos
import matplotlib.pyplot as plt         #Gráficos
from scipy.optimize import curve_fit    #Importamos el modulo scipy.optimize para hacer una regresión no lineal

class Process():
    def __init__(self):
        #Lista de verbos del habla
        self.verbs_dicendi = ['accuse', 'admit', 'advise', 'affirm', 'agree', 'agree', 'answer', 'answer', 'apologize', 'argue', 'ask', 'assure', 'assure', 'bark', 'beg', 'bellow', 'blame', 'breathe', 'call out', 'challenge', 'chuckle', 'comment', 'complain', 'compliment', 'concede', 'confess', 'confide', 'confirm', 'congratulate', 'console', 'contradict', 'convince', 'demand', 'deny', 'deny', 'describe', 'discourage', 'dispute', 'dissuade', 'encourage', 'entreat', 'exclaim', 'exclaim', 'explain', 'gasp', 'giggle', 'greet', 'growl', 'guarantee', 'hiss', 'implore', 'inquire', 'insist', 'insult', 'introduce', 'invite', 'lament', 'mention', 'mumble', 'murmur', 'mutter', 'object', 'offer', 'order', 'persuade', 'plead', 'praise', 'propose', 'rant', 'recommend', 'refuse', 'remark', 'remind', 'reply', 'request', 'respond', 'retort', 'roar', 'say', 'scoff', 'scold', 'scream', 'shout', 'sigh', 'snap', 'snarl', 'snicker', 'spat', 'splutter', 'sputter', 'state', 'suggest', 'taunt', 'tease', 'tell', 'vow', 'warn', 'whine', 'whisper', 'yell']

    #Separa un el doc_spacy (un capítulo) en sus indices, y devuelve estos, los de la narrativa si is_narative == True, los índices del diálogo en caso contrario
    def separate_text(self, chapter_spaCy, is_narrative = True):
        idx_narrative = []
        idx_dialogue = []
        for e, sent in enumerate(chapter_spaCy):
            #Si el primer token de la oración es un signo de puntuación o el verbo raíz de la oración esta en la lista de verb dicendi se cataloga como diálogo, 
            if sent[0].is_punct and sent[0].is_sent_start:
                idx_dialogue.append(e)
            elif sent.root.lemma_.lower() in self.verbs_dicendi:
                idx_dialogue.append(e)
            # en caso contrario como narrativa
            else:
                idx_narrative.append(e)
        return idx_narrative if is_narrative else idx_dialogue

    #Separa las oracines de la novela (todos los capítulos) entre narrativa y diálogo
    def separate_novel(self, novel_spaCy, is_narrative):
        text = []
        for chap in novel_spaCy.chapters:
            idx_c = self.separate_text(chap.sents, is_narrative)
            #recupera la narrativa (o diálogo) con los ínidices de las oraciones
            text.append(list(map(chap.sents.__getitem__, idx_c)))
        return text

    #Cambia el los tokens de las oraciones en el capítulo por su atributo correspondiente, hace el conteo de ocurrencia con Counter, los ordena y los devulve
    def accounts_chapt(self, chapter_spaCy, att):
        return dict(sorted(Counter([getattr(t, att) for sent in chapter_spaCy for t in sent if not t.is_space]).items()))

    #Conteo de ocurrencias en una novela
    def accounts_book(self, novel_spaCy, att, is_narrative = True):
        dic_acc = dict()
        acc_chapts = []
        # Recorre cada capítulo y encuentra su conteo de ocurrencia
        for chap in novel_spaCy.chapters:            
            idx_aux = self.separate_text(chap, is_narrative)
            if idx_aux != []:
                #obtiene la narrativa (o diálogo) a traves de sus índices
                docs = list(itemgetter(*idx_aux)(chap))
                acc_chapts.append(self.accounts_chapt(docs, att))
            else:
                print(f'No hay {"narrativa" if is_narrative else "diálogo"} en el capitulo {chap} de la novela {novel_spaCy.name_novel}')
                return dic_acc
        #Unifica el conteo de ocurrencias de cada capítulo en un diccionario de ocurrencias
        for acc in acc_chapts:
            for k in acc.keys():
                if k not in dic_acc:
                    dic_acc[k] = 0
                dic_acc[k] += acc[k]
        return dict(sorted(dic_acc.items()))

    #normaliza el diccionario de conteo de ocurrencias
    def normaliza_accounts(self, dic_acc):
        keys = list(dic_acc.keys())
        val = np.array(list(dic_acc.values()))
        return dict(zip(keys, val/val.sum()))

    #Devuelve un diccionario con el token como llave y como valor el valor que tiene en el diccionario book_acc 
    def oneonly(self, book_acc, token):
        return {token : book_acc[token]} if token in book_acc else {}
    
    #Imprime las distribuciones en forma de histograma
    def distribution_plot(self, x, y, Title=None, x_label =None, y_label=None, color='green', alpha=1, leg_on='on', max_top=10, max_label=18):
        #Encontramos los indices de las etiquetas que se mostraran si es que hay mas etiqutas que el máximo  a mostrar (max_label)    
        if len(x) > max_label:
            #haremos una muestra cada step pasos en todos los indices posibles que hay
            step = int(len(x)/max_label)
            indices_to_show = list(range(0, len(x), step))
        #Si hay menos etiquetas que el numero maximo a mostrar entonces mostramos todas las  (es decir obtenemos todos los indices)
        else:
            indices_to_show = list(range(len(x)))
        #encontramos las etiquetas a mostrar usando sus indices
        labels_to_show = [x[i] for i in indices_to_show]
        #dibujamos el grafico de barras
        plt.bar(x, y, color=color, alpha=alpha)
        #Ponemos las etiquetas encontradas y rotamos estas para mejor visualización
        plt.xticks(indices_to_show, labels_to_show, rotation=90)
        #Cambiamos la escala del eje y a logaritmica para mejor apreciación de los histogramas
        plt.yscale('log')
        #encontramos los indices de las max_top etiquetas con mayor distribución
        top_indices = np.argsort(y)[-max_top:][::-1]
        handles = []
        #encontramos cuales son estas etiquetas y sus valores
        top_labels = [x[i] for i in top_indices]
        top_values = [y[i] for i in top_indices]
        #Hacemos un recuadro para mostrar estas max_top etiquetas
        for label, value in zip(top_labels, top_values):
            handle = plt.Line2D([], [], marker='s', linestyle='None',
                                markersize=10, label=f'{label} : {round(value,6)}')
            handles.append(handle)
        #Agregamos título, y el nombre de los ejes
        plt.title(Title)
        plt.xlabel(x_label)
        plt.ylabel(y_label)
        #Por defecto se muestra esta tabla de las max_top etiquetas
        if leg_on == 'on':
            plt.legend(handles=handles, title=f'Top {max_top}', loc='center left',  bbox_to_anchor=(1.0, 0.5))
    
    #Calcula el coeficiente de correlación lineal de Pearson
    def pearson_r(self, x, y): 
        x_b = sum(x)/len(x) #media de x
        y_b = sum(y)/len(y) #media de y
        return sum((x-x_b)*(y-y_b)) / np.sqrt(sum((x - x_b) **2) * sum((y - y_b) **2)) #coeficiente de correlacion

    #Calcula el error absoluto medio (EAM)
    def mean_absolut_error(self, y, y_fit): 
        return (1/len(y))*sum(abs(y - y_fit))

    #Calcula el error cuadratico medio (ECM)
    def mean_square_error(self, y, y_fit): 
        return (1/len(y))*sum((y - y_fit)**2)

    #Calcula el error relativo medio (ECM)
    def mean_relative_error(self, y, y_fit):
        return np.mean(np.abs(y - y_fit) / y)

    #Funcion de paroximación, is is_expo == True, la función es de tipo exponencia, de lo contrario es una ley de potencias
    def function_fit(self, x, y, a0= 1, c0=-1, is_expo=False):
        # Función a ajustar
        def func(x, A, k, C):
            # Exponencial
            return A * np.exp(-(k * (x-1))) + C   
        
        def func2(x, k, B):
            # Ley de potencias
            return k*(x**B)

        if is_expo:
            # Valores iniciales
            p0 = [max(y), 0.1, min(y)]  
            #Ajuste para funcion exponencial
            popt, _ = curve_fit(func, x, y, p0)    
            A_fit, k_fit, C_fit = popt    
            y_1 = A_fit*np.exp(-k_fit*(x-1)) +  C_fit
            return A_fit, k_fit, C_fit, y_1
        else:
            p02 = [a0, c0]            
            # Ajuste para ley de potencias  
            popt2, _ = curve_fit(func2, x, y, p02)
            A_fit, C_fit = popt2
            #obtenemos el valor de la funcion aproximada
            y_1 = A_fit * (x**C_fit)
            return A_fit, C_fit, y_1
    
    #Aciva las rejillas mayores y menores de la figura a
    def activate_grid(self, a):
        # Activar ticks menores en el eje X y Y 
        a.minorticks_on() 
        # Cuadrícula principal 
        a.grid(which="major", color="black", linestyle="-", linewidth=0.8) 
        # Cuadrícula secundaria (minor grid) 
        a.grid(which="minor", color="red", linestyle="--", linewidth=0.5)