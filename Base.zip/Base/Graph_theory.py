from Process import Process
from Book import Book
from metodos_utiles import list_path_text
import networkx as nx         #Manejo de grafos
import hypernetx as hnx       #Manejo de hipergrafos
import seaborn as sns                 #Manejo de graficos
import matplotlib.pyplot as plt         #Gráficos
import numpy as np                      #Manejo eficaz de arreglos
import pandas as pd                     #Uso de dataframes
import matplotlib.cm as cm      # mapas de color
from collections import Counter         #Conteo de ocurrencias
import copy                     # para no pasar lista por referencias
#from matplotlib.colors import ListedColormap

class Graph_theory(Process):
    def __init__(self):
        super().__init__()
    
    #Funcion que genera los n-gramas de una oración
    def n_gram_4_sent(self, sent, n_gramm, att='text'):    
        return [tuple(getattr(sent[i+j], att) for j in range(n_gramm)) for i in range(len(sent) - n_gramm + 1)]
    
    #obtiene los n-gramas y los contabiliza en una lista de oraciones
    def grammas_account(self, sentences, n_gramm, att, condition):   
        return Counter([g for s in sentences for g in self.n_gram_4_sent([t for t in s if condition(t)], n_gramm, att)])

    def DiGraph_measurament(self, root_book, condition,
                            keys_digraph = ['Novela', 'Orden', 'Size', 'Grado prom', 'Grado prom in', 'Grado prom out', 'Coef agrp prom', 
                                            'Densidad', 'Orden GFC', 'diámetro', 'long tray prom']):
        Dirigido_actual = dict.fromkeys(keys_digraph)
        novel = Book(root_book, condition)
        Dirigido_actual['Novela'] = novel.name_novel
        narrativa = self.separate_novel(novel, True)
        sentences_n = [sent for chap in narrativa for sent in chap]
        edges_dirigido = [bigram for sent in sentences_n for bigram in self.n_gram_4_sent([token for token in sent if condition(token) and token.pos_ != 'SYM' and token.pos_ != 'NUM'], 2, 'text')]
        G = nx.DiGraph()
        G.add_edges_from(edges_dirigido)
        
        #print(f'El orden del grafo es: {G.order()}\nel grado es: \n{G.degree()} \ndividido en: \n\tentrante: \n{G.in_degree()}, \n\tsailente: \n{G.out_degree()}')
        Dirigido_actual['Orden'] = G.order()
        Dirigido_actual['Grado prom in'] = sum(dict(G.in_degree()).values()) / G.order()
        Dirigido_actual['Grado prom out'] = sum(dict(G.out_degree()).values()) / G.order()
        Dirigido_actual['Grado prom'] = sum(dict(G.degree()).values()) / G.order()
        Dirigido_actual['Size'] = G.size()
        Dirigido_actual['Coef agrp prom'] = nx.average_clustering(G)
        Dirigido_actual['Densidad'] = nx.density(G)
        #De todos los subgrafos debilmente conexos se toma el mas grande
        subG = G.subgraph(max(list(nx.weakly_connected_components(G)), key=len))
        #DE todos los componente fuertemente conexos del subgrafo mas grande, se toma el mayor
        subGSCC = G.subgraph(max(list(nx.strongly_connected_components(subG)), key=len))
        Dirigido_actual['Orden GFC'] = subGSCC.order()

        diameter = 0
        total = 0
        n = subGSCC.number_of_nodes()

        for _, d in nx.all_pairs_shortest_path_length(subGSCC):
            diameter = max(diameter, max(d.values()))
            total += sum(d.values())

        avg_path = total / (n*(n-1))

        Dirigido_actual['diámetro'] = diameter
        Dirigido_actual['long tray prom'] = avg_path
        
        #nx.draw(G, with_labels=False, node_color='lightblue', edge_color='gray', arrowsize=20)
        #plt.show()
        return Dirigido_actual

    def DiGraf_Analisis(self, root_path, condition):
        Dirigidos_ = []
        for root_book in list_path_text(root_path):
            Dirigidos_.append(self.DiGraph_measurament(root_book, condition))
            print(f'Termine de analizar la novela {root_book.split(".")[1]}')
        return pd.DataFrame(Dirigidos_)
    
    def hypergraph(self, text_, att, keys):
        dict_att = {k:[] for k in keys}
        for token in text_:
            if getattr(token, att) in dict_att.keys():
            #    dict_att[str(getattr(token, att))] = []
                dict_att[str(getattr(token, att))] += [token.text]
        #sorted(dict_att.items())
        llaves = list(dict_att.keys())
        valores = [sorted(set(nodes)) for nodes in list(dict_att.values())]
        return dict(sorted(zip(llaves, valores)))
    
    def paint_hypergraph(self, H, att, name_novel, is_murdoch=True, with_node_labels=False, with_edge_labels=True, figsize=(18, 10)):
        plt.subplots(figsize=figsize)
        hnx.draw(H, 
                with_node_labels=with_node_labels,
                with_edge_labels=with_edge_labels,)
                #  edge_label_kwargs={'fontsize':12})
        plt.title(f'Hipergrafo de la narrativa de las categorias {att} \nen la novela {name_novel} de {"IM" if is_murdoch else "PD James"}')
        plt.show()

    def complete_matix(self, matrix):
        matrix = np.array(matrix)
        matrix = matrix + matrix.T - np.diag(np.diag(matrix))
        return matrix
    
    def frame_hyperedges(self, matrix, h_G):
        df = pd.DataFrame((matrix.tolist()), columns=list(h_G.edges), index = list(h_G.edges))
        mask = df == 0
        return df, mask
    
    def heat_map(self, figsize, df, title, mask, vmin=0, vmax=2):
        plt.figure(figsize=figsize)
        sns.heatmap(df, annot=True, cmap="turbo", vmin= vmin, vmax= vmax)
        sns.heatmap(df, mask=~mask, cmap="Reds", cbar=False)
        # Número de hiperaristas
        n = df.shape[0]
        # Máscara de la diagonal
        diag_mask = np.eye(n, dtype=bool)
        # Heatmap para la diagonal
        sns.heatmap(
            df,
            mask=~diag_mask,  # solo diagonal
            annot=True,
            cmap= "Greys",      
            cbar=False,
            linewidths=0.5
        )
        plt.title(title)
        plt.show()

    def hypergraph_metrics(self, root_book, attr, figsize, condition, keys):
    #    v_inter = []
    #    v_jaccar = []
    #    v_ovearlap = []
        metrics = dict.fromkeys(['Grado min', 'Grado max', 'Grado prom'], None)
        novel = Book(root_book, condition)
        narrativa = self.separate_novel(novel, True)
        text_plane = [t for chap in narrativa for sent in chap for t in sent if condition(t)]
        h_G = hnx.Hypergraph(self.hypergraph(text_plane, att= attr, keys= keys))
    #    h_G.remove_edges('PUNCT')    
    #    h_G.remove_edges('SYM')    
        #Matriz de interseccion entre aristas
        m_zeros = [[0 for _ in range(len(h_G.edges))] for _ in range(len(h_G.edges))]
        matriz = copy.deepcopy(m_zeros)
        matriz_jaccar = copy.deepcopy(m_zeros)
        matriz_ovearlap = copy.deepcopy(m_zeros)
        edges = list(h_G.edges)
        for col, edge1 in enumerate(edges):
            for row, edge2 in enumerate(edges[col:]):
                e1 = set(h_G.edges[edge1])
                e2 = set(h_G.edges[edge2])
                matriz_jaccar[col][row + col] = len(e1 & e2) / len(e1 | e2)
                matriz[col][row + col] = len(e1 & e2) / h_G.order() 
                matriz_ovearlap[col][row + col] = len(e1 & e2) / min(len(e1), len(e2))

        matriz_ovearlap = self.complete_matix(matriz_ovearlap)
        matriz = self.complete_matix(matriz)
        matriz_jaccar = self.complete_matix(matriz_jaccar)

        df_ovearlap, mask_ovearlap = self.frame_hyperedges(matriz_ovearlap, h_G)
        #df_ovearlap = df_ovearlap.round(4)

        df_intersection, mask = self.frame_hyperedges(matriz, h_G)
        #df_intersection = df_intersection.round(6)*100

        df_jaccar,  mask_jaccar  = self.frame_hyperedges(matriz_jaccar, h_G)
        #df_jaccar = df_jaccar.round(4)

#        self.heat_map(figsize, df_ovearlap.round(4), f'Matriz Ovearlap de las categorías {attr} \nen la novela {novel.name_novel}', mask_ovearlap, vmin= df_ovearlap.min().min(), vmax= df_ovearlap.max().max())
#        self.heat_map(figsize, df_jaccar.round(4), f'Matriz Jaccar de las categorías {attr} \nen la novela {novel.name_novel}', mask_jaccar, vmin= df_jaccar.min().min(), vmax= df_jaccar.max().max())
#        self.heat_map(figsize, df_intersection.round(6)*100, f'Porcentaje de nodos intersectados entre las categorías {attr} \nen la novela {novel.name_novel}', mask)

        #Diccionario de aritas con los nodos que contiene
        edges_dict = {e: 0 for e in h_G.edges}
        for edge in h_G.edges:
            edges_dict[edge] = list(h_G.edges[edge])
        
#        print(f'El orden del grafo es: {h_G.order()}')
        metrics['Orden'] = h_G.order()
        #{e: h_G.size(e)/h_G.order() for e in h_G.edges}
        for e in h_G.edges:
            metrics[f'{e} % Nodos'] = (h_G.size(e)/h_G.order())*100
#            print(f'La hiperaritas {e} tiene {h_G.size(e)} nodos, \n{round(metrics[f"{e} % Nodos"]*100, 4)}% de los nodos de la red')
        
        #Grado de los nodos
        degree = {n: h_G.degree(n) for n in h_G.nodes()}
        degree_min = min(degree.values())
        metrics['Grado min'] = degree_min 
        degree_max = max(degree.values())
        metrics['Grado max'] = degree_max
        degree_mean = sum(degree.values())/len(degree)
        metrics['Grado prom'] = degree_mean
        for g in set(list(degree.values())):
            act_nodes = [d[0] for d in degree.items() if d[1]==g]
            metrics[f'% de nodos con grado {g}'] = (len(act_nodes)/h_G.order())*100
#            print(f'Hay {len(act_nodes)} nodos con grado {g} son el {(len(act_nodes)/h_G.order())*100} % de la red: \n{act_nodes}')

        
        size_edges = {h: h_G.size(h) for h in h_G.edges}
        for h_e, s_e in size_edges.items():
            metrics[f'{h_e} % Aristas'] = (s_e / sum(list(size_edges.values())))*100
        #densidad del hipergrafo basada en el tamaño de las hiperaritas
    #    density_H = sum(size_edges.values()) / (h_G.order()*len(h_G.edges))
    #    metrics['Densidad'] =  density_H
        #Matrices
        #Incidencia del hipergrafo
        df_incidence = h_G.incidence_dataframe()
        #df_incidence.to_excel(os.path.join(os.path.join('Resultados', 'Hipergrafos'), f'Incidencia_{novel.name_novel}.xlsx'), index = True)
        #metrics['Incidencia'] =  df_incidence
        
        #Adyacencia del hipergrafo
        df_ady = h_G.adjacency_matrix()
        df_ady = pd.DataFrame(df_ady.toarray())
        df_ady.columns = h_G.nodes()
        df_ady.index = h_G.nodes()

    #    i, j = np.triu_indices(matriz.shape[0], k=1)

        #df_ady.to_excel(os.path.join(os.path.join('Resultados', 'Hipergrafos'), f'Adyascencia_{novel.name_novel}.xlsx'), index = True)
    # metrics['Adyascencia'] =  df_ady
    #    paint_hypergraph(h_G, attr, novel.name_novel, is_murdoch=True)
        return metrics, df_intersection, df_incidence, df_ady, df_jaccar, df_ovearlap

    def all_Hyper(self, path_root, att, condition, figsize, keys):
        filas = []
    #    filas_int = []
    #    filas_jac = []
    #    filas_ovear = []
        novelas = []
        
        for path in list_path_text(path_root):
            metrics, df_intersection, df_incidence, df_ady, df_jac, df_ovear =self.hypergraph_metrics(root_book = path, attr= att, figsize=figsize, condition=condition, keys= keys)
            name_novel = path.split('.')[-3].strip().replace(' ','_').replace(',','')
            novelas.append(name_novel)
            filas.append(metrics)
    #  v_int, v_jac, v_ovear solo la matriz diagonal superior aplanada de sus respectivos dataframes df_intersection, df_jac, df_ovear
    #        filas_int.append({name_novel: v_int})
    #        filas_jac.append({name_novel: v_jac})
    #        filas_ovear.append({name_novel: v_ovear})
            print(f'termine de analizar la novela {name_novel}')
            #path_first = os.path.join('Resultados', 'Hipergrafos')
            #df_intersection.to_excel(os.path.join(path_first, f'Intersections_{name_novel}.xlsx'), index = True)
            #df_incidence.to_excel(os.path.join(path_first, f'Incidencia_{name_novel}.xlsx'), index = True)
            #df_ady.to_csv(os.path.join(path_first, f'Adyascencia_{name_novel}.csv'), index = True)
            print(f'termine de guardar la novela {name_novel}')
        return pd.DataFrame(filas, index = novelas)#,  pd.DataFrame(filas_int, index = novelas), pd.DataFrame(filas_jac, index = novelas), pd.DataFrame(filas_ovear, index = novelas)#.to_excel(os.path.join(path_first, f'{"I_Murdoch" if is_murdoch else "PD_James"}_{att}.xlsx'), index=True)    
    
    def s_armonic_centrality(self, H, name_novel, att):
        centralidades = dict()
        for i in range(1, 350, 3):
            centralidades[i] = hnx.algorithms.s_centrality_measures.s_harmonic_centrality(H, s=i, normalized=True)
        centralidad_for_label = dict(zip(list(H.edges), [np.array([v[edge] for k, v in centralidades.items()]) for edge in list(H.edges)]))
        edges = list(H.edges)
        cmap = cm.tab20_r  
        colors = cmap(np.linspace(0, 1, len(edges)))
        for e, label in enumerate(edges):
            plt.plot(list(centralidades.keys()), centralidad_for_label[label], label=f'{label}', color=colors[e], linewidth=10-(e/2)) 
        self.activate_grid(plt)
        plt.ylabel(f'Centralidad armónica de las etiquetas tipo {att}')
        plt.xlabel(f's- nodos conectados')
        plt.title(f'Centralidad armónica de hiperaristas vs s-nodos conectados mínimos\nen la novela {name_novel}')
        plt.legend()
        plt.show()
        return centralidades
    
    def s_armonics_all(self, root_path, att, condition, keys):
        centralidades = []
        for root_book in list_path_text(root_path):
            novel = Book(root_book, condition)
            narrative = self.separate_novel(novel, True)
            text_plane = [t for chap in narrative for sent in chap for t in sent if condition(t)]
            h_G = hnx.Hypergraph(self.hypergraph(text_plane, att= att, keys=keys))
            centralidades.append({novel.name_novel :self.s_armonic_centrality(h_G, novel.name_novel, att)})
        return centralidades