import re           #uso de expresiones regulares
from Chapter import Chapter      # Clase Chapter
from metodos_utiles import condition_clean, condition_clean_stop
import spacy        #Procesamiento del lenguaje natural

#Carga del modelo mediano en idioma inglés de spacy
nlp = spacy.load('en_core_web_md')

class Book():
    #Dependiendo de condition, cambia el valor de len en la oracion, con condition_clean no toma en cuenta los signos de puntuación ni espacios en blanco
# con condition_clean_stop no toma en cuenta los signos de puntuación ni espacios en blanco ni los stopwords
    def __init__(self, root_book, condition):
        self.chapters = []
        self.name_novel = root_book.split('.')[-3]
        chapters_ = self.prepare_text_in_chapters(root_book)
        for e, chap in enumerate(chapters_):
            doc = nlp(chap)
            self.chapters.append(Chapter(doc, e, condition))

    #se habilita para que funcione como iteravble
    def __iter__(self):
        return iter(self.chapters)        

    #Se habilita para obtener el tamaño del iterable
    def __len__(self):
        return len(self.chapters)
   
    #Se habilita su representación dando el nombre de la novela y el total de capítulos a la representación del objeto Book
    def __repr__(self):
        return f'libro: {self.name_novel}, capítulos: {len(self.chapters)}'
    
    #lee un archivo pasandole su ruta
    def read_file(self, path):
        #Se abre con with para cerrar el archivo de forma automatica y pasa un encondin utf-8
        with open(path, 'r', encoding="utf-8") as f:
            #Se lee el archivo, se pasa a minusculas y se quitan espacios en blanco extras
            return f.read().lower().strip()

    #limpia un texto    
    def clean_text(self, text):
        # Limpieza básica: eliminar saltos de línea, caracteres invisibles y unicode raros
        return re.sub(r'[\n\r\u2028\u2029\ufff0-\uffff\ufeff]+', ' ', text).strip()

    #Separa los signos de las palabras
    def separate_punctuation(self, text):
        # Pone espacios alrededor de cualquier signo de puntuación excepto el apóstrofe (')
        return re.sub(r"([^\w\s'])", r' \1 ', text)

    #obtiene los capitulos del texto
    def text_in_chapters(self, clean_text):
        #Encontramos los capitulos con la marca manual puesta al final de cada capitulo
        chapts = clean_text.split('####')
        return [self.separate_punctuation(t.strip()) for t in chapts]

    #Pasando la ruta de la novela, lee el archivo, limpia el texto y lo separa por capítulos
    def prepare_text_in_chapters(self, root_book):
        novel = self.read_file(root_book)
        return self.text_in_chapters(self.clean_text(novel))