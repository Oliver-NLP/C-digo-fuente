#Es el objeto mas básico de todo el texto
class Token():
    # Fijamos los atributos de la clase para acelerar el proceso
    __slots__ = (
        'i', 'is_stop', 'is_punct', 'is_space', 'is_sent_start',
        'lemma_', 'pos_', 'tag_', 'dep_', 'text', 'head', 'dd'
    )
    #recive un token que se obtuvo con spaCy y copiamos solo los atributos que utilizaremos
    def __init__(self, token_spacy):
        self.i = token_spacy.i                          #int: identificador unico dentro del documento
        self.is_stop = token_spacy.is_stop              #bool: True si es stop word, False en otro caso (eoc)
        self.is_punct = token_spacy.is_punct            #bool: True si es un signo de puntuacion, False eoc
        self.is_space = token_spacy.is_space            #bool: True si es un espacio en blanco, False eoc
        self.is_sent_start = token_spacy.is_sent_start  #bool: True si es el inicio de una oracion
        self.lemma_ = token_spacy.lemma_                #str: con el lema
        self.pos_ = token_spacy.pos_                    #str: con la etiqueta pos
        self.tag_ = token_spacy.tag_                    #str: con la etiqueta tag
        self.dep_ = token_spacy.dep_                    #str: dependencia con su gobernante
        self.text = token_spacy.text                    #str: cadena del token
        self.head = token_spacy.head                    #str: con su gobernante
        # Inicializamos la distancia de dependencia en 0
        self.dd = 0                                     #(int: distancia de dependencia)

    #se representa como su cadena de texto
    def __repr__(self):
        return self.text
    
    #Se habilita que funcione como un iterados para recorrer cada letra
    def __iter__(self):
        return iter(self.text)
    
    #Se habilita el tamaño del token
    def __len__(self):
        return sum([1 for l in self.text])