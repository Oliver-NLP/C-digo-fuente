from Token import Token
from metodos_utiles import condition_clean, condition_clean_stop

#Es una lista de objetos tipo Token_primitive
class Sent_token():
    __slots__ = (
        'root', 'tokens', 'i', 'condition'
    )
#Dependiendo de condition, cambia el valor de len en la oracion, con condition_clean no toma en cuenta los signos de puntuación ni espacios en blanco
# con condition_clean_stop no toma en cuenta los signos de puntuación ni espacios en blanco ni los stopwords

    #Recibe una oración tokenizada por spaCy
    def __init__(self, sent_spacy, condition):
        #Obtenemos el verbo raíz de la oración
        self.root = sent_spacy.root 
        #obtenemos nuestra lista de objetos Token_primitive de la oración
        self.tokens = [Token(t) for t in sent_spacy]
        #Se inicializa su identificador en None
        self.i = None
        self.condition = condition

    #se habilita la obtencion de los atributos 
    def __getitem__(self, start, end=None):
        #Si solo se pide un elemento
        if end == None:
            return self.tokens[start]
        #Si se pide una sublista de tokens de la oración entonces solo se regrsa esta y no solo un elemento
        else:
            start_ = self.tokens[start].i
            end_ = self.tokens[end].i
            return [x for x in self.tokens if x.i>= start_ and x.i<=end_]

    #Se habilita para la lectura de len, se toma en cuenta que spacy tokeniza los puntos y espacios en blanco por lo que 
    #cuando se devuelve el tamaño de la oración estos se desprecian
    def __len__(self):
        return sum([1 for t in self.tokens if self.condition(t)])#not t.is_space and not t.is_punct])

    #Se habilita para que trabaje como un iterable el cual contiene los tokens primitivos de la oracion
    def __iter__(self):
        return iter(self.tokens)

    #Se habilita su representación como cadena de texto 
    def __repr__(self):
        return " ".join([t.text for t in self.tokens if not t.is_space])